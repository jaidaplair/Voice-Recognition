// Toggle the visibility of the dog image
function showDog() {
    const dogImage = document.getElementById('dog');
    if (dogImage.style.display === 'none' || dogImage.style.display === '') {
        //show dog
        dogImage.style.display = 'block';
        console.log(dogImage.style.display,"should be showing")
    } 
    else {
        //dont show dog
        dogImage.style.display = 'none';
        console.log(dogImage.style.display,"Should be hidden")
    }
}

// Show an alert with the text entered in the input field
function showAlert() {
    const input = document.getElementById('myInput');
    if (input && input.value.trim() !== '') {
        alert(input.value); // Show the alert with the input value
        input.value = '';   // Clear the input field
    } else {
        alert('Please enter some text!');
    }
}

// Start speech recognition
function startRecognition() {
    // Check if the browser supports SpeechRecognition
    if (!('SpeechRecognition' in window || 'webkitSpeechRecognition' in window)) {
        alert('Speech recognition is not supported in this browser.');
        return;
    }

    const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();

    recognition.onstart = () => {
        console.log('Speech recognition started...');
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript.toLowerCase();
        console.log(`Recognized speech: ${transcript}`);

        // Regular expression to match commands
        const re = /^(click|scroll|enter)\s(.*)/i;
        const result = re.exec(transcript);

        if (result) {
            const verb = result[1];  // e.g., "click"
            const arg = result[2];   // e.g., "button"

            switch (verb) {
                case 'click':
                    handleClick(arg);
                    break;

                case 'scroll':
                    handleScroll(arg);
                    break;

                case 'enter':
                    handleEnter(arg);
                    break;

                default:
                    //did say a command or didnt hear person
                    alert('Command not recognized.');
            }
        } else {
            //if person said something that isnt known
            alert('Unrecognized command!');
        }
    };

    recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        alert('Error occurred during speech recognition.');
    };

    recognition.start();
}

function handleClick(arg) {
    if (arg.includes('button')) {
        const buttons = document.querySelectorAll('button');
        let clicked = false;
        buttons.forEach(button => {
            if (button.textContent.toLowerCase().includes(arg.replace('button', '').trim())) {
                button.click();
                clicked = true;
            }
        });
        if (!clicked) alert('No matching button found.');
    } else if (arg.includes('link')) {
        const links = document.querySelectorAll('a');
        let clicked = false;
        links.forEach(link => {
            if (link.textContent.toLowerCase().includes(arg.replace('link', '').trim())) {
                link.click();
                clicked = true;
            }
        });
        if (!clicked) alert('No matching link found.');
    } else {
        alert('Please specify either a button or link to click.');
    }
}


// Handle "scroll" command
function handleScroll(arg) {
    if (arg === 'down') {
        window.scrollBy(0, 100);
    } else if (arg === 'up') {
        window.scrollBy(0, -100);
    } else {
        alert('Invalid scroll direction!');
    }
}

// Handle "enter" command
function handleEnter(arg) {
    const input = document.getElementById('myInput');
    if (input) {
        input.value = arg;
    } else {
        alert('Input field not found.');
    }
}
